가상환경 생성

필요한 라이브러리 설치

scikit-surprise를 설치 전 Microsoft Visual C++ Build Tools 설치

Microsoft Visual C++ Build Tools 설치
Microsoft Visual C++ Build Tools 웹사이트를 방문합니다.
"Download Build Tools"를 클릭하여 다운로드합니다.
다운로드한 설치 프로그램을 실행합니다.
설치 화면에서 "Desktop development with C++" 워크로드를 선택하고 설치를 진행합니다.

scikit-surprise 패키지 설치