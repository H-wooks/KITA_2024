import os
from typing import List
from langchain_community.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document
from langchain_openai import ChatOpenAI

# OpenAI API 키 설정
os.environ["OPENAI_API_KEY"] = "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"

# Text 파일에서 특정 섹션을 추출하는 함수
def get_text_from_file(filename, section_title):
    with open(filename, 'r', encoding='utf-8') as file:
        content = file.read()
    start_marker = f"{section_title}=\"\"\""
    end_marker = "\"\"\""
    start_index = content.find(start_marker)
    end_index = content.find(end_marker, start_index + len(start_marker))
    if start_index != -1 and end_index != -1:
        return content[start_index + len(start_marker):end_index].strip()
    else:
        return "해당 섹션을 찾을 수 없습니다."

# 가져온 텍스트를 FAISS 인덱스로 변환하는 함수
def create_faiss_index_from_text(text):
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=0,
        separators=["\n\n", "\n", ".", " "],
    )
    chunks = text_splitter.split_text(text)
    documents = [Document(page_content=chunk) for chunk in chunks]
    faiss_index = FAISS.from_documents(documents, OpenAIEmbeddings())
    return faiss_index

# 파일에서 counseling_guides 텍스트 가져오기
counseling_guides_text = get_text_from_file('D:\\kdt_240424\\workspace\\M6_DL_ChatBot\\Guides.txt', "counseling_guides")
drawing_guides_text = get_text_from_file('D:\\kdt_240424\\workspace\\M6_DL_ChatBot\\Guides.txt', "drawing_guides")

# FAISS 인덱스 생성
faiss_counseling_index = create_faiss_index_from_text(counseling_guides_text)
faiss_drawing_index = create_faiss_index_from_text(drawing_guides_text)

# Custom Retriever 함수 정의
def combined_retriever(query: str) -> List[Document]:
    drawing_results = faiss_drawing_index.similarity_search(query)
    counseling_results = faiss_counseling_index.similarity_search(query)
    return drawing_results + counseling_results

# LLM 설정 (OpenAI API 사용)
llm = ChatOpenAI(model="gpt-4o-mini-2024-07-18", temperature=0.8)

# 특정 역할 설정
role_prompt = """
당신은 심리 상담가이자 미술치료 상담사입니다. 사용자가 질문할 때, 미술 치료와 심리 상담의 가이드에 따라 사용자의 상태를 파악하고, 그에 맞는 조언을 제공하세요.
미술 치료와 관련된 답변을 할 때는 drawing_results를 참고하고, 심리 상담과 관련된 답변을 할 때는 당신은 정신건강 전문가이자 정신과 의사입니다. counseling_results를 참고해서
항상 친절하고 공감하는 태도로 대화하세요.
"""

# RetrievalQA 체인 생성
qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    chain_type="stuff",
    retriever=faiss_drawing_index.as_retriever(),  # 여기서는 단일 retriever로 생성
)


query = """
    요즘 기분도 많이 다운되고, 친구,가족과 대화하기도 싫고 일에 의욕도 없어. 내가 우을증을 겪고 있는건가? 우을증 진단 할 수 있어? 
"""
# 그런 기분을 느끼고 계시다니 안타깝습니다. 우울한 기분은 누구에게나 찾아올 수 있는 것이고, 그럴 때는 주변 사람들과 이야기하는 것이 도움이 될 수 있습니다. 
# 하지만 대화하기도 싫고 의욕이 없을 때는 정말 힘들죠. 이럴 때는 전문적인 도움을 받는 것도 좋은 방법입니다. 상담을 받거나, 자신이 신뢰할 수 있는 사람과 이 
# 야기해보는 것을 고려해 보세요.

response = qa_chain.run(query)

print(response)

# # 질문 입력 및 답변 생성
# query = """
#     심리진단을 위해서 사람/나무/집 그림을 그렸는데 사용자가 그린 나무는 가지가 앙상하고, 
#     열매도 잎도 하나도 없이 그렸어. 그리고, 집 그림은 창문도 없고, 
#     집을 위에서 본 구조로 그렸어. 사람의 경우 얼굴이 비현실적으로 크게 그리고, 
#     굴의 이목구비가 조금 생략되어 있고 희미하게 그렸고 어깨는 양쪽이 비대칭이야.. 
#     현재 사용자의 심리 상태 분석 가능할까 ?
# """
# # 사용자가 그린 나무, 집, 사람 그림의 각 요소를 통해 심리 상태를 분석해볼 수 있습니다.
# # 1. **나무**: 가지가 앙상하고 열매나 잎이 없는 나무는 개인의 정서적 고립감이나 무기력함을 나타낼 수 있습니다. 이는 개인의
# #  삶에서의 어려움이나 감정적 결핍을 반영할 수 있으며, 무의식적으로 느끼는 불안정한 심리 상태를 나타낼 수 있습니다.       
# # 2. **집**: 창문이 없는 집은 외부와의 소통 부족이나 고립된 느낌을 상징할 수 있습니다. 집을 위에서 본 구조로 그린 것은 자 
# # 신의 내면 세계를 타인에게 드러내지 않으려는 경향을 나타낼 수 있으며, 이는 가족이나 가까운 관계에서의 불안정함을 시사할  
# # 수 있습니다.
# # 3. **사람**: 얼굴이 비현실적으로 크고 이목구비가 생략된 것은 자아 정체성의 혼란이나 자신에 대한 불만족을 나타낼 수 있습 
# # 니다. 비대칭적인 어깨는 내적 갈등이나 불균형한 감정 상태를 반영할 수 있습니다. 이는 대인 관계에서의 불안정함이나 자신감 
# # 부족을 나타낼 수 있습니다.
# # 종합적으로 볼 때, 사용자의 그림은 정서적 고립감, 자아 정체성의 혼란, 대인 관계에서의 불안정함을 나타내는 것으로 해석될  
# # 수 있습니다. 이러한 요소들은 사용자가 현재 심리적으로 어려움을 겪고 있음을 시사합니다.


