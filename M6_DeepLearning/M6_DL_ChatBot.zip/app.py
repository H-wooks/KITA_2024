from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from openai import OpenAI
import os
import base64
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from config import *
import config
from models import db, User, Diary
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_migrate import Migrate
from flask_session import Session  # Flask-Session 추가
from datetime import timedelta

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///diary.db'
app.secret_key = '03e232504425fc9b66c7b76b1c19093288fd3739953cbb59'

# 이거이거
app.permanent_session_lifetime = timedelta(minutes=5)
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_FILE_DIR'] = os.path.join(app.root_path, 'flask_session')
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_USE_SIGNER'] = True
app.config['SESSION_KEY_PREFIX'] = 'mysession:'
Session(app)  # Flask-Session 초기화
# Upload folder setup
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

db.init_app(app)  # 애플리케이션에 db 객체 등록
migrate = Migrate(app, db)

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

if not os.path.exists(app.config['SESSION_FILE_DIR']):
    os.makedirs(app.config['SESSION_FILE_DIR'])

# OpenAI API 키 설정
client = OpenAI(api_key="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")

def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")

def handle_user_input(user_input=None, image_path=None, mode='counseling'):
    MODEL = "gpt-4o-mini-2024-07-18"

    if mode == 'drawing_analysis':
        system_message = config.drawing_guides
        temperature = 0.9  # 창의성을 조금 높임
        max_tokens = 1000  # 답변의 길이를 증가
        top_p = 0.95
        #top_k = 100        
    else:
        system_message = config.counseling_guides
        temperature = 0.8
        max_tokens = 300  # 상담에선 너무 길지 않게
        top_p = 1.0
        #top_k = 50        

    # 0823 MS 추가. 세션에 저장된 대화 기록 가져오기
    messages = [{"role": "system", "content": system_message}] + session.get('history', [])

    # (0826 MS) counseling mode 에서의 few-shot example:
    if mode == 'counseling':
        messages.extend(config.few_shot_examples)
        messages.extend(config.dbt_examples)

    
    if image_path:
        base64_image = encode_image(image_path)
        messages.append(
            {"role": "user", "content": [
                {"type": "text", "text": "이 그림을 그린 나의 심리 상태를 분석해줘"},
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}}
            ]} 
        )
    else:
        messages.append({"role": "user", "content": user_input})

    response = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        temperature=temperature,  # 각 모드에 따른 temperature 사용
        max_tokens=max_tokens,    # 각 모드에 따른 max_tokens 사용
        top_p=top_p,              # 각 모드에 따른 top_p 사용
        #top_k=top_k               # 각 모드에 따른 top_k 사용
    )
    
    return response.choices[0].message.content


@app.route('/')
def realindex():
    # 새로운 세션이 시작되면 모든 상태 초기화
    session.clear()
    session['mode'] = 'counseling'  # 기본적으로 상담 모드로 설정
    session['diagnosis'] = {}
    session['follow_up'] = False
    session['history'] = []  # 대화 기록 초기화
    return render_template('real_index.html')

# @app.route('/real_index')
# def real_index():
#     return render_template('')

@app.route('/real_index')
def real_index():
    return render_template('real_index.html')

@app.route('/index', methods=['GET','POST'])
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get('message').strip()

    # 세션 초기화 부분
    if 'mode' not in session:
        session['mode'] = 'counseling'
        session['diagnosis'] = {}
        session['diagnosis_completed'] = 0
        session['history'] = []

    # 대화 히스토리에 사용자 입력 추가
    session['history'].append({"role": "user", "content": user_input})

    # 사용자가 특정 설문조사를 요청할 때
    if user_input in survey_data:
        session['mode'] = 'survey'
        session['survey_type'] = user_input
        session['questions'] = survey_data[user_input]['questions']
        session['current_question'] = 0
        session['total_score'] = 0
        session['score_range'] = survey_data[user_input]['score_range']
        session['diagnosis_completed'] = 0
        
        response = f"{user_input} 설문조사를 시작합니다. 각 문항에 대해 {session['score_range']} 점 중 선택하여 답변해 주세요.\n{session['questions'][0][0]} (점수: {session['score_range']})"
        session['history'].append({"role": "system", "content": response})
        return jsonify({'response': response}), 200

    # 설문조사 모드일 때
    if session.get('mode') == 'survey':
        try:
            user_score = int(user_input)

            if not 0 <= user_score <= int(session['score_range'][-1]):
                return jsonify({'response': f"점수는 {session['score_range']} 범위 내에서 입력해 주세요."}), 200

            question_text, is_reverse = session['questions'][session['current_question']]
            if session['survey_type'] == '공황장애 진단' and session['current_question'] == 13:
                user_score *= 20  # 마지막 질문에 대해 점수를 20배 곱함

            if is_reverse:
                user_score = int(session['score_range'][-1]) - user_score

            session['total_score'] += user_score
            session['current_question'] += 1
        except ValueError:
            return jsonify({'response': f'점수를 {session["score_range"]} 범위 내에서 숫자로 입력해 주세요.'}), 200

        if session['current_question'] < len(session['questions']):            
            next_question = session['questions'][session['current_question']][0]
            response = f"{session['current_question'] + 1}. {next_question} (점수: {session['score_range']})"
            session['history'].append({"role": "system", "content": response})
            return jsonify({'response': response}), 200
        else:
            total_score = session['total_score']
            scoring = survey_data[session['survey_type']]['scoring']

            # 진단 결과 도출
            diagnosis = next(d for min_score, max_score, d in scoring if min_score <= total_score <= max_score)
            session['diagnosis']['survey'] = {'type': session['survey_type'], 'result': diagnosis}
            
            # 사용자에게 피드백 전달
            comment = diagnosis_comments[session['survey_type']][diagnosis]

            session['mode'] = 'counseling'
            session['diagnosis_completed'] = 1

            response = f"설문이 완료되었습니다. 총점: {total_score}. 진단: {diagnosis}. {comment} \n심리 진단을 완료했어요. 진단 결과에 대해 어떻게 생각하시나요? 추가적으로 이야기하고 싶은 내용이 있으시면 말씀해 주세요."
            session['history'].append({"role": "system", "content": response})
            return jsonify({'response': response}), 200

    # 그림 심리 진단 요청 시
    if user_input == "그림 심리 진단":
        session['mode'] = 'drawing_analysis'
        response = '그림 심리 진단을 시작합니다. 심리 진단을 위한 사람, 집, 나무에 대한 그림 파일을 업로드해주세요.'
        session['history'].append({"role": "system", "content": response})
        return jsonify({'response': response}), 200

    # 그림 심리 진단 모드일 때
    if session.get('mode') == 'drawing_analysis':
        response = '파일을 업로드 해주세요. 아래의 업로드 폼을 이용하세요.'
        session['history'].append({"role": "system", "content": response})
        return jsonify({'response': response}), 200

    # 나이와 성별 입력을 받기 위한 상태 체크
    if session.get('mode') == 'awaiting_age_gender':
        # 나이와 성별을 별도로 세션에 저장
        session['age'] = user_input.split()[0]  # 나이 저장
        session['gender'] = user_input.split()[1]  # 성별 저장
        session['age_gender'] = user_input
        session['history'].append({"role": "user", "content": f"입력받은 정보: {user_input}"})
        session['mode'] = 'counseling'  # 상담 모드로 복귀
        response = ('필요하시면 간단한 설문조사를 통해 현재의 심리 상태를 진단해 드릴 수 있습니다. '
                    '다음 중 원하시는 항목을 입력해 주세요. "우울증 진단", "공황장애 진단", "불면증 진단", "불안장애 진단", "자아존중감 진단", "그림 심리 진단"')
        session['history'].append({"role": "system", "content": response})
        return jsonify({'response': response}), 200

    # 상담 모드일 때
    if session.get('mode') == 'counseling':
        if "진단 실행" in user_input:
            session['mode'] = 'awaiting_age_gender'
            if 'age' in session and 'gender' in session:
                response = f"당신은 {session['age']}세 {session['gender']} 이라고 하셨죠?"
                session['history'].append({"role": "system", "content": response})
            else:
                # 나이와 성별이 없는 경우에만 물음
                response = ("좀 더 정확한 진단을 위해서 나이와 성별을 입력해주세요. 예를 들어 '25세 남성', 혹은 '40세 여성'으로 입력해주세요.")
                session['history'].append({"role": "system", "content": response})
            return jsonify({'response': response}), 200
        else:
            counseling_response = handle_user_input(user_input=user_input, mode='counseling')
            session['history'].append({"role": "system", "content": counseling_response})
            return jsonify({'response': counseling_response}), 200

    return jsonify({'response': '죄송합니다, 요청하신 내용을 처리할 수 없습니다. 다시 시도해 주세요.'}), 400

# @app.route('/diary_index')
# def diary_index():
#     return render_template("diary_index.html")

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'response': '파일이 포함되어 있지 않습니다.'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'response': '선택된 파일이 없습니다.'}), 400

    if file:
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        # Call the drawing analysis function
        analysis_result_dummy = handle_user_input(image_path=file_path, mode='drawing_analysis')

        # 분석 결과에 불릿 포인트와 문단 추가
        #analysis_result = analysis_result_dummy.replace('1.', '\n1.').replace('2.', '\n2.').replace('3.', '\n3.').replace('4.', '\n4.').replace('종합적', '\n종합적')
        analysis_result = analysis_result_dummy.replace('### ', '').replace('**','') #\
            # .replace('1.', '\n1.') \
            # .replace('2.', '\n2.') \
            # .replace('3.', '\n3.') \
            # .replace('4.', '\n4.') \
            # .replace('종합적', '\n종합적')

        # Switch to counseling mode and save the result
        session['mode'] = 'counseling'
        session['diagnosis_completed'] = 1
        session['diagnosis']['drawing'] = analysis_result

        session['history'].append({"role": "system", "content": analysis_result})
        # JSON 응답으로 HTML 콘텐츠를 반환
        return jsonify({
            'response': f"\n{analysis_result} \n분석 결과에 대해 추가적으로 이야기하고 싶은 내용이 있으시면 말씀해 주세요."
        }), 200

# +++++++++++++++++++++=======================================================================
@app.route('/join', methods=['GET', 'POST'])
def join():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if User.query.filter_by(username=username).first():
            flash('중복된 아이디 입니다!')
            return redirect(url_for('join'))
        new_user = User(username=username)
        new_user.set_password(password)
        db.session.add(new_user)
        db.session.commit()
        flash('회원가입 성공!!')
        return redirect(url_for('login'))
    return render_template('join.html')

# @app.route('/join', methods=['GET', 'POST'])
# def join():
#     if request.method == 'POST':
#         username = request.form['username']
#         password = request.form['password']
        
#         # 사용자 중복 확인
#         if User.query.filter_by(username=username).first():
#             flash('중복된 아이디 입니다!')  # 중복된 사용자에 대한 메시지
#             return redirect(url_for('join'))
        
#         # 새로운 사용자 추가
#         new_user = User(username=username)
#         new_user.set_password(password)
#         db.session.add(new_user)
#         db.session.commit()
        
#         flash('회원가입 성공!')  # 회원가입 성공 메시지
#         return redirect(url_for('index'))
    
#     return render_template('join.html')


# @app.route('/login', methods=['POST'])
# def login():
#     username = request.form['username']
#     password = request.form['password']
#     user = User.query.filter_by(username=username).first()
#     if user and user.check_password(password):
#         session['user_id'] = user.id
#         flash('Logged in successfully!')
#         return redirect(url_for('diary_index'))
#     flash('Invalid credentials!')
#     return redirect(url_for('real_index'))
# @app.route('/login', methods=['GET', 'POST'])
# def login():
#     if request.method == 'POST':
#         username = request.form['username']
#         password = request.form['password']
#         user = User.query.filter_by(username=username).first()
#         if user and user.check_password(password):
#             session['user_id'] = user.id
#             flash('Logged in successfully!')
#             return redirect(url_for('diary_index'))
#         flash('Invalid credentials!')
#         return redirect(url_for('diary_index'))
    
#     # GET 요청 시 로그인 페이지를 렌더링합니다.
#     return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('diary_index'))

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        
        # 비밀번호 검증
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session.permanent = True
            flash('로그인 성공!')
            return redirect(url_for('diary_index'))
        
        flash('로그인 실패!')
        return redirect(url_for('login'))
    
    return render_template('login.html')



@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Logged out successfully!')
    return redirect(url_for('login'))

@app.route('/diary_index')
def diary_index():
    page = request.args.get('page', 1, type=int)
    user_id = session['user_id']
    diaries = Diary.query.filter_by(user_id=user_id).paginate(page=page, per_page=10, error_out=False)

    return render_template('diary_index.html', diaries=diaries)

@app.route('/diary')
def diary():
    if 'user_id' not in session:
        flash('You need to log in first!')
        return redirect(url_for('index'))
    page = request.args.get('page', 1, type=int)
    user_id = session['user_id']
    # diaries = Diary.query.filter_by(user_id=user_id).paginate(page, 10, False)
    diaries = Diary.query.filter_by(user_id=user_id).paginate(page=page, per_page=10, error_out=False)

    return render_template('diary.html', diaries=diaries)

@app.route('/new_diary', methods=['GET', 'POST'])
def new_diary():
    if 'user_id' not in session:
        flash('You need to log in first!')
        return redirect(url_for('index'))
    if request.method == 'POST':
        title = request.form['title']
        contents = request.form['contents']
        mood = request.form['mood']
        sleep_time = request.form['sleep_time']
        weather = request.form['weather']
        new_diary = Diary(
            title=title, contents=contents, mood=int(mood), 
            sleep_time=int(sleep_time), weather=weather, 
            user_id=session['user_id']
        )
        db.session.add(new_diary)
        db.session.commit()
        flash('Diary entry created!')
        return redirect(url_for('diary_index'))
    return render_template('new_diary.html')

@app.route('/diary/<int:diary_id>')
def diary_contents(diary_id):
    if 'user_id' not in session:
        flash('You need to log in first!')
        return redirect(url_for('index'))
    diary = Diary.query.get_or_404(diary_id)
    return render_template('diary_contents.html', diary=diary)

@app.route('/get_diary/<int:diary_id>')
def get_diary(diary_id):
    diary = Diary.query.get_or_404(diary_id)
    diary_data = {
        'title': diary.title,
        'contents': diary.contents,
        'weather': diary.weather,
        'sleep_time': diary.sleep_time,
        'mood': diary.mood,
        'date': diary.date.strftime('%Y-%m-%d')
    }
    return jsonify(diary_data)

@app.route('/diary/update/<int:diary_id>', methods=['POST'])
def update_diary(diary_id):
    if 'user_id' not in session:
        flash('You need to log in first!')
        return redirect(url_for('index'))

    diary = Diary.query.get_or_404(diary_id)
    diary.title = request.form['title']
    diary.contents = request.form['contents']
    diary.mood = int(request.form['mood'])
    diary.sleep_time = int(request.form['sleep_time'])
    diary.weather = request.form['weather']

    db.session.commit()
    flash('Diary entry updated successfully!')
    return redirect(url_for('diary_index', diary_id=diary.id))


@app.route('/edit_diary/<int:diary_id>', methods=['GET', 'POST'])
def edit_diary(diary_id):
    diary = Diary.query.get_or_404(diary_id)
    
    if request.method == 'POST':
        diary.title = request.form['title']
        diary.contents = request.form['contents']
        diary.weather = request.form['weather']
        diary.sleep_time = float(request.form['sleep_time'])
        diary.mood = int(request.form['mood'])
        diary.date = request.form['date']
        
        db.session.commit()
        
        flash('Diary entry updated successfully!')
        return redirect(url_for('index'))

    mood_labels = ["아주 좋음", "좋음", "보통", "안 좋음", "매우 안 좋음"]
    return render_template('edit_diary.html', diary=diary, mood_labels=mood_labels)

@app.route('/delete_diary/<int:diary_id>', methods=['POST'])
def delete_diary(diary_id):
    diary = Diary.query.get_or_404(diary_id)  # ID로 다이어리 검색, 없으면 404 오류 발생

    # 세션의 사용자와 다이어리 작성자가 동일한지 확인
    if 'user_id' not in session or diary.user_id != session['user_id']:
        flash('You are not authorized to delete this diary entry.')
        return redirect(url_for('diary_index'))
    
    db.session.delete(diary)  # 다이어리 삭제
    db.session.commit()  # 데이터베이스에 변경사항 저장
    
    flash('Diary entry deleted successfully!')
    return redirect(url_for('diary_index'))


if __name__ == "__main__":
    app.run(debug=True)
