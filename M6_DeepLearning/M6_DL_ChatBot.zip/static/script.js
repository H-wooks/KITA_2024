// document.addEventListener("DOMContentLoaded", function () {
//     var modal = document.getElementById("loginModal");
//     var btn = document.getElementById("loginBtn");
//     var span = document.getElementsByClassName("close")[0];

//     btn.onclick = function () {
//         modal.style.display = "block";
//     }

//     span.onclick = function () {
//         modal.style.display = "none";
//     }

//     window.onclick = function (event) {
//         if (event.target == modal) {
//             modal.style.display = "none";
//         }
//     }

//     document.getElementById('diary_index_div').onclick = function() {
//         window.location.href = "/diary_index";
//     }
    
//     document.getElementById('chatbot_index_div').onclick = function() {
//         window.location.href = "/index";
//     }
// });
document.addEventListener("DOMContentLoaded", function () {
    var modal = document.getElementById("loginModal");
    var btn = document.getElementById("loginBtn");
    var span = document.getElementsByClassName("close")[0];

    btn.onclick = function () {
        modal.style.display = "block";
    }

    span.onclick = function () {
        modal.style.display = "none";
    }

    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
});



async function sendMessage() {
    const userInput = document.getElementById('userInput').value;
    const chatbox = document.getElementById('chatbox');
    
    // 사용자 메시지를 채팅 박스에 추가
    const userMessageDiv = document.createElement('div');
    userMessageDiv.className = 'user-message';
    userMessageDiv.textContent = userInput;
    chatbox.appendChild(userMessageDiv);

    try {
        // 사용자 메시지를 서버로 전송
        const response = await fetch('/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: userInput }),
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();

        // 챗봇의 응답을 채팅 박스에 추가
        const botMessageDiv = document.createElement('div');
        botMessageDiv.className = 'bot-message';
        botMessageDiv.textContent = data.response;
        chatbox.appendChild(botMessageDiv);

        // "그림 심리 진단" 요청 시 파일 입력 폼 표시
        if (userInput.toLowerCase() === "그림 심리 진단") {
            document.getElementById('textInputContainer').style.display = 'none';
            document.getElementById('fileInputContainer').style.display = 'flex';
        }

    } catch (error) {
        console.error('Error:', error);
        const errorMessageDiv = document.createElement('div');
        errorMessageDiv.className = 'bot-message';
        errorMessageDiv.textContent = 'An error occurred. Please try again later.';
        chatbox.appendChild(errorMessageDiv);
    } finally {
        // 입력 필드 초기화
        document.getElementById('userInput').value = '';
    }
}

// Enter 키를 눌렀을 때 sendMessage 함수를 호출하는 함수
function checkEnter(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
}

async function uploadFile() {
    const fileInput = document.getElementById('fileInput');
    const chatbox = document.getElementById('chatbox');
    const file = fileInput.files[0];

    if (!file) {
        const errorMessageDiv = document.createElement('div');
        errorMessageDiv.className = 'bot-message';
        errorMessageDiv.textContent = 'Please select a file.';
        chatbox.appendChild(errorMessageDiv);
        return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch('/upload', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();

        // 챗봇의 응답을 채팅 박스에 추가
        const botMessageDiv = document.createElement('div');
        botMessageDiv.className = 'bot-message';
        botMessageDiv.textContent = data.response;
        chatbox.appendChild(botMessageDiv);

        // 파일 업로드 후 원래 텍스트 입력 폼으로 복귀
        document.getElementById('fileInputContainer').style.display = 'none';
        document.getElementById('textInputContainer').style.display = 'flex';

    } catch (error) {
        console.error('Error:', error);
        const errorMessageDiv = document.createElement('div');
        errorMessageDiv.className = 'bot-message';
        errorMessageDiv.textContent = 'An error occurred during file upload. Please try again later.';
        chatbox.appendChild(errorMessageDiv);
    } finally {
        // 파일 입력 필드 초기화
        fileInput.value = '';
    }
}

function opendiarypage() {
    window.open("/login", "_blank");
}

document.addEventListener('DOMContentLoaded', function() {
    const diaryLinks = document.querySelectorAll('.diary-link');

    diaryLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const diaryId = this.getAttribute('data-diary-id');
            
            fetch(`/get_diary/${diaryId}`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('diary-title').textContent = data.title;
                    document.getElementById('diary-contents').textContent = data.contents;
                    document.getElementById('diary-weather').textContent = '날씨 : ' + data.weather;
                    document.getElementById('diary-sleep-time').textContent = '어제 수면시간 : ' + data.sleep_time + ' 시간';

                    // 감정에 대한 조건문 처리
                    let moodText = '';
                    switch (data.mood) {
                        case 0:
                            moodText = '아주 좋음 😀';
                            break;
                        case 1:
                            moodText = '좋음 😏';
                            break;
                        case 2:
                            moodText = '보통 😐';
                            break;
                        case 3:
                            moodText = '나쁨 😠';
                            break;
                        case 4:
                            moodText = '아주 나쁨 😡';
                            break;
                        default:
                            moodText = '알 수 없음';
                    }

                    document.getElementById('diary-mood').textContent = '감정 : ' + moodText;
                    document.getElementById('diary-date').textContent = '작성일 : ' + data.date;

                    // Edit 링크 업데이트
                    document.getElementById('edit-link').href = `/edit_diary/${diaryId}`;
                });
        });
    });
});


document.getElementById("diary-date").style.display = 'none';
document.getElementById("diary-mood").style.display = 'none';
document.getElementById("diary-weather").style.display = 'none';
document.getElementById("diary-sleep-time").style.display = 'none';
document.getElementById("diary-contents").style.display = 'none';
document.getElementById("edit-link-div").style.display = 'none';

document.querySelectorAll('.diary-link').forEach(function(link) {
    link.addEventListener('click', function(event) {
        event.preventDefault();
        
        var diaryId = this.getAttribute('data-diary-id');
        var diaryDate = document.getElementById("diary-date");
        var diaryMood = document.getElementById("diary-mood");
        var diaryWeather = document.getElementById("diary-weather");
        var diarySleepTime = document.getElementById("diary-sleep-time");
        var diaryContents = document.getElementById("diary-contents");
        var editLinkDiv = document.getElementById("edit-link-div");
        
        
        diaryDate.style.display = 'block';
        diaryMood.style.display = 'block';
        diaryWeather.style.display = 'block';
        diarySleepTime.style.display = 'block';
        diaryContents.style.display = 'block';
        editLinkDiv.style.display = 'block';
        diaryDate.innerHTML = '<p>일기 ID: ' + diaryId + '에 대한 내용이 표시됩니다.</p>';
    });
});