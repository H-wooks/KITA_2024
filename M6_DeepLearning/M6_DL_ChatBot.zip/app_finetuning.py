from flask import Flask, render_template, request, jsonify
import openai
import time

app = Flask(__name__)

# OpenAI API 키 설정
#openai.api_key = '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'  # 실제 API 키로 교체합니다.
#강사님 keys
openai.api_key = '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'

# 데이터 업로드 및 미세 조정 작업
def upload_file(file_path):
    try:
        file_response = openai.File.create(
            file=open(file_path, "rb"),
            purpose='fine-tune'
        )
        return file_response['id']
    except openai.error.OpenAIError as e:
        print(f"Error uploading file: {e}")
        return None

# 미세 조정 작업 생성
def create_fine_tune(training_file_id, model="gpt-4o-mini-2024-07-18"):
    try:
        fine_tune_response = openai.FineTuningJob.create(
            training_file=training_file_id,
            model=model
        )
        return fine_tune_response['id']
    except openai.error.OpenAIError as e:
        print(f"Error creating fine-tune: {e}")
        return None

# 미세 조정 작업 상태 확인
def get_fine_tune_status(fine_tune_id):
    try:
        while True:
            status_response = openai.FineTuningJob.retrieve(id=fine_tune_id)
            status = status_response['status']
            print(f"Current status: {status}")  # 상태를 출력하여 디버깅
            if status == 'succeeded':
                return status_response['fine_tuned_model']
            elif status == 'failed':
                print(status_response)  # 실패 시 추가 정보를 출력
                raise Exception("Fine-tuning failed")
            time.sleep(60)
    except openai.error.OpenAIError as e:
        print(f"Error retrieving fine-tune status: {e}")
        return None

# 전체 프로세스 실행
def fine_tune_model():
    training_file_id = upload_file(r"D:\kdt_240424\workspace\M6_DL_ChatBot\training_data.jsonl")
    if training_file_id is None:
        raise Exception("File upload failed")

    fine_tune_id = create_fine_tune(training_file_id)
    if fine_tune_id is None:
        raise Exception("Fine-tune creation failed")

    fine_tuned_model_id = get_fine_tune_status(fine_tune_id)
    if fine_tuned_model_id is None:
        raise Exception("Fine-tune status retrieval failed")

    return fine_tuned_model_id

# 미세 조정된 모델 ID 가져오기
fine_tuned_model_id = fine_tune_model()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    try:
        user_input = request.json.get('message')
        survey_type = request.json.get('survey_type')  # 'depression', 'anxiety' 또는 'general'

        if survey_type == 'depression':
            prompt = f"Depression Survey: {user_input}"
        elif survey_type == 'anxiety':
            prompt = f"Anxiety Survey: {user_input}"
        else:
            prompt = f"General Conversation: {user_input}"

        response = openai.ChatCompletion.create(
            model=fine_tuned_model_id,
            messages=[
                {"role": "system", "content": "당신은 심리 상담 전문가이며 정신과 의사입니다. 사용자에게 적절한 심리 상담과 조언, 그리고 편안한 대화 상대가 되어주세요"},
                {"role": "user", "content": prompt}
            ]
        )
        return jsonify({'response': response.choices[0].message['content'].strip()})
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'response': 'An error occurred. Please try again later.'}), 500

if __name__ == '__main__':
    app.run(debug=True)